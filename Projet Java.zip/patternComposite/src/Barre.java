@SuppressWarnings("unused")
public class Barre implements Produit {

	private double poids = 0;
	private double prix = 0;
	private String codeBarre;
    private String descriptif;
    private double longueur;

    public Barre(double prix, String descriptif, String codeBarre, double poids, double longueur) {
		this.prix=prix;
		this.descriptif=descriptif;
		this.codeBarre=codeBarre;
		this.poids=poids;
		this.longueur=longueur;
	}

	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getCodeBarre() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDescriptif() {
		// TODO Auto-generated method stub
		return null;
	}

}
