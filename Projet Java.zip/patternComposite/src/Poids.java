@SuppressWarnings("unused")
public class Poids implements Produit {

    private double poids;
    private double prix;
    private String codeBarre;
    private String descriptif;
    
	public Poids(double prix, String descriptif, String codeBarre, double poids) {
		this.prix=prix;
		this.descriptif=descriptif;
		this.codeBarre=codeBarre;
		this.poids=poids;
	}

	@Override
	public double getPrix() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getCodeBarre() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDescriptif() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
