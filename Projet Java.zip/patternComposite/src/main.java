
public class main {

	public static void main(String[] args) {
		// 							Prix 	Descriptif 					CodeBarre 	Poids	Longueur
		Barre maBarre = new Barre(	25.0, 	"Barre d'halt�rophilie", 	"BA0001",	2.0, 	150.0);
		
		// 							Prix 	Descriptif 					CodeBarre 	Poids
		Poids leger = new Poids(	15.0, 	"Poids d'halt�re", 			"PA0001", 	0.5);
		Poids moyen = new Poids(	17.0, 	"Poids d'halt�re", 			"PA0002", 	1.0);
		Poids lourd = new Poids(	19.0, 	"Poids d'halt�re", 			"PA0003", 	1.5);

		ProduitComposite haltere = new ProduitComposite();
		haltere.add(maBarre);
		haltere.add(leger);
		haltere.add(moyen);
		haltere.add(lourd);

	}
}
