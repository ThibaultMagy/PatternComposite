public interface Produit {
	
    public double getPrix();
    public String getCodeBarre();
    public String getDescriptif();

}


