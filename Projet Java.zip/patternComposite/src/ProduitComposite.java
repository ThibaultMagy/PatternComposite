import java.util.ArrayList;
import java.util.Collection;
@SuppressWarnings("unused")
public class ProduitComposite implements Produit {

    private Collection<Produit> children;
    private String codeBarre;
    private String descriptif;
    
	public ProduitComposite() {
        children = new ArrayList<Produit>();
    }

    public void add(Produit produit){
        children.add(produit);
    }

    public void remove(Produit produit){
        children.remove(produit);
    }

    public Collection<Produit> getChildren() {
        return children;
    }

    public String getCodeBarre() {
        return codeBarre;
    }

    public String getDescriptif() {
        String result = new String();
        result="descriptif : (";

        for (Produit child : children) {
            result+=child.getDescriptif()+", ";
        }
        
        result+=")";
        return result;
    }

    public double getPrix() {
        double result = 0;
        for (Produit child : children) {
            result += child.getPrix();
        }
        result = result * 0.9;
        return result;
    }
}


